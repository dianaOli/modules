import Post from './Post.mjs';

const myPost = new Post("Hello World", "This is my first blog post!");
myPost.publish();
