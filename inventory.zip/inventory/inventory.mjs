const inventory = [];

export function addItem(name) {
  inventory.push(name);
  console.log(`${name} added to inventory.`);
}

export function removeItem(name) {
  const index = inventory.indexOf(name);
  if (index !== -1) {
    inventory.splice(index, 1);
    console.log(`${name} removed from inventory.`);
  } else {
    console.log(`${name} not found in inventory.`);
  }
}

export function listItems() {
  console.log("Current inventory:");
  inventory.forEach(item => console.log(`- ${item}`));
}
