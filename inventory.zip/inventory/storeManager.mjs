import { addItem, removeItem, listItems } from './inventory.mjs';

addItem('Laptop');
addItem('Headphones');
addItem('Mouse');
removeItem('Headphones');
listItems();
