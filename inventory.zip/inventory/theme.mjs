export function setLightTheme() {
  console.log("Light theme activated.");
}

export function setDarkTheme() {
  console.log("Dark theme activated.");
}
