import { capitalize, toLowerCase, add, multiply } from './utils/index.mjs';
import './globalConfig.mjs';


console.log(capitalize("hello"));         // Hello
console.log(toLowerCase("WORLD"));        // world
console.log(add(5, 10));                  // 15
console.log(multiply(3, 7));              // 21
