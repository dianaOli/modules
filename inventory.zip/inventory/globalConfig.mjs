console.log("Global configuration loaded.");
